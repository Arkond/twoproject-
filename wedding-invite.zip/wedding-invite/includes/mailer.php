<?php

declare(strict_types=1);

function send_guest_notice(array $app, array $mailConfig, array $guest): array
{
    if (empty($app['enable_email_notice']) || empty($mailConfig['enabled'])) {
        return [
            'success' => false,
            'skipped' => true,
            'error' => 'Email-уведомления отключены в настройках.',
        ];
    }

    $to = (string)$app['admin_email'];
    $statusText = $guest['attendance_status'] === 'yes' ? 'Придёт' : 'Не сможет прийти';
    $subject = 'Новый ответ на свадебное приглашение';
    $body = "Новый ответ гостя:\n\n"
        . "Имя: {$guest['first_name']}\n"
        . "Фамилия: {$guest['last_name']}\n"
        . "Ответ: {$statusText}\n"
        . "Дата отправки: " . date('d.m.Y H:i') . "\n";

    return smtp_send_mail($mailConfig, $to, $subject, $body);
}

function smtp_send_mail(array $config, string $to, string $subject, string $body): array
{
    $host = (string)$config['host'];
    $port = (int)$config['port'];
    $encryption = (string)($config['encryption'] ?? 'tls');
    $username = (string)$config['username'];
    $password = (string)$config['password'];
    $fromEmail = (string)$config['from_email'];
    $fromName = (string)$config['from_name'];

    $remote = $encryption === 'ssl' ? 'ssl://' . $host : $host;
    $socket = @fsockopen($remote, $port, $errno, $errstr, 15);

    if (!$socket) {
        return ['success' => false, 'error' => "SMTP connection error: {$errstr} ({$errno})"];
    }

    stream_set_timeout($socket, 15);

    $read = static function () use ($socket): string {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        return $response;
    };

    $send = static function (string $command) use ($socket, $read): string {
        fwrite($socket, $command . "\r\n");
        return $read();
    };

    $expect = static function (string $response, array $codes): bool {
        $code = substr($response, 0, 3);
        return in_array($code, $codes, true);
    };

    $initial = $read();
    if (!$expect($initial, ['220'])) {
        fclose($socket);
        return ['success' => false, 'error' => trim($initial)];
    }

    $ehlo = $send('EHLO localhost');
    if (!$expect($ehlo, ['250'])) {
        fclose($socket);
        return ['success' => false, 'error' => trim($ehlo)];
    }

    if ($encryption === 'tls') {
        $startTls = $send('STARTTLS');
        if (!$expect($startTls, ['220'])) {
            fclose($socket);
            return ['success' => false, 'error' => trim($startTls)];
        }

        if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            fclose($socket);
            return ['success' => false, 'error' => 'Не удалось включить TLS для SMTP.'];
        }

        $ehlo = $send('EHLO localhost');
        if (!$expect($ehlo, ['250'])) {
            fclose($socket);
            return ['success' => false, 'error' => trim($ehlo)];
        }
    }

    $auth = $send('AUTH LOGIN');
    if (!$expect($auth, ['334'])) {
        fclose($socket);
        return ['success' => false, 'error' => trim($auth)];
    }

    $loginResponse = $send(base64_encode($username));
    if (!$expect($loginResponse, ['334'])) {
        fclose($socket);
        return ['success' => false, 'error' => trim($loginResponse)];
    }

    $passResponse = $send(base64_encode($password));
    if (!$expect($passResponse, ['235'])) {
        fclose($socket);
        return ['success' => false, 'error' => trim($passResponse)];
    }

    $mailFrom = $send('MAIL FROM:<' . $fromEmail . '>');
    if (!$expect($mailFrom, ['250'])) {
        fclose($socket);
        return ['success' => false, 'error' => trim($mailFrom)];
    }

    $rcptTo = $send('RCPT TO:<' . $to . '>');
    if (!$expect($rcptTo, ['250', '251'])) {
        fclose($socket);
        return ['success' => false, 'error' => trim($rcptTo)];
    }

    $data = $send('DATA');
    if (!$expect($data, ['354'])) {
        fclose($socket);
        return ['success' => false, 'error' => trim($data)];
    }

    $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $encodedFromName = '=?UTF-8?B?' . base64_encode($fromName) . '?=';

    $message = '';
    $message .= "From: {$encodedFromName} <{$fromEmail}>\r\n";
    $message .= "To: <{$to}>\r\n";
    $message .= "Subject: {$encodedSubject}\r\n";
    $message .= "MIME-Version: 1.0\r\n";
    $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $message .= "Content-Transfer-Encoding: 8bit\r\n";
    $message .= "\r\n";
    $message .= str_replace("\n.", "\n..", $body);
    $message .= "\r\n.";

    fwrite($socket, $message . "\r\n");
    $final = $read();

    $quit = $send('QUIT');
    fclose($socket);

    if (!$expect($final, ['250'])) {
        return ['success' => false, 'error' => trim($final)];
    }

    return ['success' => true, 'error' => null, 'smtp_quit' => trim($quit)];
}
