<?php

declare(strict_types=1);

require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/mailer.php';

start_secure_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(false, 'Некорректный способ отправки формы.', 405);
}

if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
    json_response(false, 'Не удалось проверить форму. Обновите страницу и попробуйте ещё раз.', 400);
}

$lastSubmitAt = $_SESSION['last_guest_response_at'] ?? 0;
if (is_int($lastSubmitAt) && time() - $lastSubmitAt < 20) {
    json_response(false, 'Вы уже недавно отправляли ответ. Попробуйте позже.', 429);
}

$firstName = clean_string($_POST['first_name'] ?? '', 80);
$lastName = clean_string($_POST['last_name'] ?? '', 80);
$attendanceStatus = clean_string($_POST['attendance_status'] ?? '', 10);

if ($firstName === '' || $lastName === '' || !in_array($attendanceStatus, ['yes', 'no'], true)) {
    json_response(false, 'Заполните имя, фамилию и выберите ответ.', 422);
}

require_once __DIR__ . '/../config/db.php';

try {
    $stmt = $pdo->prepare(
        'INSERT INTO guest_responses (first_name, last_name, attendance_status, ip_address, user_agent)
         VALUES (:first_name, :last_name, :attendance_status, :ip_address, :user_agent)'
    );

    $stmt->execute([
        ':first_name' => $firstName,
        ':last_name' => $lastName,
        ':attendance_status' => $attendanceStatus,
        ':ip_address' => client_ip(),
        ':user_agent' => user_agent(),
    ]);

    $_SESSION['last_guest_response_at'] = time();

    $app = require __DIR__ . '/../config/app.php';
    $mailConfig = require __DIR__ . '/../config/mail.php';

    $mailResult = send_guest_notice($app, $mailConfig, [
        'first_name' => $firstName,
        'last_name' => $lastName,
        'attendance_status' => $attendanceStatus,
    ]);

    if (empty($mailResult['skipped'])) {
        $logStmt = $pdo->prepare(
            'INSERT INTO email_logs (recipient, subject, status, error_text)
             VALUES (:recipient, :subject, :status, :error_text)'
        );
        $logStmt->execute([
            ':recipient' => (string)$app['admin_email'],
            ':subject' => 'Новый ответ на свадебное приглашение',
            ':status' => !empty($mailResult['success']) ? 'success' : 'error',
            ':error_text' => $mailResult['error'] ?? null,
        ]);
    }

    json_response(true, 'Спасибо! Ваш ответ сохранён.');
} catch (Throwable $e) {
    error_log('Guest response error: ' . $e->getMessage());
    json_response(false, 'Не удалось отправить ответ. Попробуйте ещё раз.', 500);
}
