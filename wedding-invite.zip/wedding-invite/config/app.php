<?php

return [
    'site_title' => 'Свадебное приглашение',
    'bride_name' => 'Имя невесты',
    'groom_name' => 'Имя жениха',
    'wedding_date' => '2026-08-15 15:00:00',
    'wedding_date_label' => '15 августа 2026',

    'restaurant_name' => 'Название ресторана',
    'restaurant_address' => 'г. Стерлитамак, ул. Гоголя, 175',
    'map_url' => 'https://yandex.ru/maps/?text=г.%20Стерлитамак,%20ул.%20Гоголя,%20175',
    'map_iframe_url' => 'https://yandex.ru/map-widget/v1/?text=г.%20Стерлитамак,%20ул.%20Гоголя,%20175&z=16',

    'bride_phone' => '8 (986) 971-46-26',
    'bride_phone_href' => '+79869714626',
    'groom_phone' => '8 (987) 489-26-12',
    'groom_phone_href' => '+79874892612',
    'host_name' => 'Артур Губайдуллин',
    'host_phone' => '8 (987) 017-01-09',
    'host_phone_href' => '+79870170109',

    'contact_name' => 'Организатор',
    'contact_phone' => '+7 (999) 999-99-99',
    'contact_phone_href' => '+79999999999',

    'admin_email' => 'example@mail.ru',
    'enable_email_notice' => false,
];
