<?php

return [
    // Поставьте true, когда заполните реальные SMTP-данные.
    'enabled' => false,

    'host' => 'smtp.example.com',
    'port' => 587,
    // Допустимые значения: tls, ssl, none
    'encryption' => 'tls',

    'username' => 'example@mail.ru',
    'password' => 'password',
    'from_email' => 'example@mail.ru',
    'from_name' => 'Свадебное приглашение',
];
