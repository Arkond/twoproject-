document.addEventListener('DOMContentLoaded', () => {
    const footer = document.querySelector('[data-wedding-date]');
    const timer = document.querySelector('[data-timer]');

    if (!footer || !timer) {
        return;
    }

    const weddingDate = new Date(footer.dataset.weddingDate.replace(' ', 'T'));
    const days = document.querySelector('[data-days]');
    const hours = document.querySelector('[data-hours]');
    const minutes = document.querySelector('[data-minutes]');
    const seconds = document.querySelector('[data-seconds]');

    const pad = (value) => String(value).padStart(2, '0');

    const updateTimer = () => {
        const now = new Date();
        const diff = weddingDate.getTime() - now.getTime();

        if (Number.isNaN(weddingDate.getTime()) || diff <= 0) {
            days.textContent = '00';
            hours.textContent = '00';
            minutes.textContent = '00';
            seconds.textContent = '00';
            return;
        }

        const totalSeconds = Math.floor(diff / 1000);
        const d = Math.floor(totalSeconds / 86400);
        const h = Math.floor((totalSeconds % 86400) / 3600);
        const m = Math.floor((totalSeconds % 3600) / 60);
        const s = totalSeconds % 60;

        days.textContent = pad(d);
        hours.textContent = pad(h);
        minutes.textContent = pad(m);
        seconds.textContent = pad(s);
    };

    updateTimer();
    setInterval(updateTimer, 1000);
});
