document.addEventListener('DOMContentLoaded', () => {
    const button = document.querySelector('[data-music-button]');
    const text = document.querySelector('[data-music-text]');
    const audio = document.querySelector('[data-wedding-audio]');

    if (!button || !text || !audio) {
        return;
    }

    button.addEventListener('click', async () => {
        if (audio.paused) {
            try {
                await audio.play();
                button.classList.add('is-playing');
                text.textContent = 'Выключить музыку';
            } catch (error) {
                text.textContent = 'Музыка недоступна';
                button.classList.remove('is-playing');
            }
            return;
        }

        audio.pause();
        button.classList.remove('is-playing');
        text.textContent = 'Включить музыку';
    });
});
