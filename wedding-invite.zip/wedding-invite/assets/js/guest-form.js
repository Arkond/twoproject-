document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('[data-guest-form]');
    const message = document.querySelector('[data-form-message]');
    const submitButton = document.querySelector('[data-submit-button]');

    if (!form || !message || !submitButton) {
        return;
    }

    const setMessage = (text, type = '') => {
        message.textContent = text;
        message.classList.remove('is-success', 'is-error');

        if (type) {
            message.classList.add(`is-${type}`);
        }
    };

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const formData = new FormData(form);
        const firstName = String(formData.get('first_name') || '').trim();
        const lastName = String(formData.get('last_name') || '').trim();
        const attendance = String(formData.get('attendance_status') || '').trim();

        if (!firstName || !lastName || !attendance) {
            setMessage('Заполните имя, фамилию и выберите ответ.', 'error');
            return;
        }

        submitButton.disabled = true;
        submitButton.textContent = 'Отправляем...';
        setMessage('');

        try {
            const response = await fetch('api/guest-response.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                },
            });

            const result = await response.json();

            if (!response.ok || !result.success) {
                setMessage(result.message || 'Не удалось отправить ответ. Попробуйте ещё раз.', 'error');
                return;
            }

            form.reset();
            setMessage(result.message || 'Спасибо! Ваш ответ сохранён.', 'success');
        } catch (error) {
            setMessage('Не удалось отправить ответ. Попробуйте ещё раз.', 'error');
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = 'Отправить';
        }
    });
});
