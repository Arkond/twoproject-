<?php

declare(strict_types=1);

require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';

start_secure_session();
$app = require __DIR__ . '/config/app.php';
$csrf = csrf_token();
$names = trim($app['groom_name'] . ' & ' . $app['bride_name']);
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($app['site_title']) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body>
    <div class="page-shell">
        <div class="music-row">
            <button class="music-button" type="button" data-music-button>
                <span class="music-button__dot"></span>
                <span data-music-text>Включить музыку</span>
            </button>
        </div>

        <audio data-wedding-audio preload="none" loop>
            <source src="assets/audio/wedding.mp3" type="audio/mpeg">
        </audio>

        <main>
            <section class="hero section reveal reveal-center">
                <div class="hero__photo photo-frame photo-frame--hero">
                    <img src="assets/img/placeholders/hero.svg" alt="Фотография молодожёнов">
                    <div class="hero__fade"></div>
                    <div class="hero__overlay">

                        <div class="hero__names"><?= h($names) ?></div>
                        <div class="hero__date"><?= h($app['wedding_date_label']) ?></div>
                    </div>
                </div>
            </section>

            <section class="section invitation reveal reveal-center">
                <h1>Дорогие гости!</h1>
                <div class="invitation__text">
                    <p>В нашей жизни состоится<br>важное событие —<br><strong>наша свадьба!</strong></p>
                    <p>И мы хотели бы разделить<br>этот счастливый день с вами.</p>
                </div>
                <div class="photo-pair photo-pair--intro">
                    <div class="photo-frame photo-pair__item photo-pair__item--left reveal reveal-left">
                        <img src="assets/img/placeholders/couple-1.svg" alt="Фото пары">
                    </div>
                    <div class="photo-frame photo-pair__item photo-pair__item--right reveal reveal-right">
                        <img src="assets/img/placeholders/couple-2.svg" alt="Фото пары">
                    </div>
                </div>

            </section>

            <section class="section timing reveal reveal-center">
                <h2>Тайминг</h2>
                <div class="timeline timeline--centered">
                    <div class="timeline__item">
                        <span>15:00</span>
                        <p>Сбор гостей</p>
                    </div>
                    <div class="timeline__item">
                        <span>15:20</span>
                        <p>Выездная регистрация</p>
                    </div>
                    <div class="timeline__item">
                        <span>16:00</span>
                        <p>Фотосессия, фуршет</p>
                    </div>
                    <div class="timeline__item">
                        <span>16:30</span>
                        <p>Свадебный банкет</p>
                    </div>
                </div>
            </section>

            <section class="section location reveal reveal-center">
                <h2>Локация</h2>
                <div class="location-visual">
                    <img src="assets/img/placeholders/location.svg" alt="Место проведения свадьбы">
                    <div class="map-glass" aria-label="Карта места проведения">
                        <iframe
                            src="<?= h($app['map_iframe_url']) ?>"
                            loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"
                            allowfullscreen>
                        </iframe>
                    </div>
                </div>
                <div class="location__text">
                    <span>Ресторан</span>
                    <strong>«<?= h($app['restaurant_name']) ?>»</strong>
                    <p><?= h($app['restaurant_address']) ?></p>
                </div>
                <a class="button button--map" href="<?= h($app['map_url']) ?>" target="_blank" rel="noopener">Посмотреть на карте</a>
            </section>

            <section class="section dress-code reveal reveal-center">
                <h2>Дресс-код</h2>
                <p class="section-text">
                    Нам будет приятно, если вы поддержите нас и выберете спокойную,
                    однотонную цветовую гамму без ярких вызывающих цветов.
                </p>

                <div class="dress-layout">
                    <article class="dress-part reveal reveal-left">
                        <h3>Леди</h3>
                        <p>
                            Будем рады видеть вас в нарядах пастельных оттенков.
                            Белый цвет зарезервирован невестой.
                        </p>
                        <div class="palette palette--overlap" aria-label="Цвета для леди">
                            <span style="--color:#dfc9c1"></span>
                            <span style="--color:#d9d2c3"></span>
                            <span style="--color:#c8b9a6"></span>
                            <span style="--color:#b9c4b0"></span>
                        </div>
                    </article>

                    <article class="dress-part reveal reveal-right">
                        <h3>Джентльмены</h3>
                        <p>
                            Просим выбрать сдержанные оттенки, которые будут сочетаться
                            с общей атмосферой праздника.
                        </p>
                        <div class="palette palette--overlap" aria-label="Цвета для джентльменов">
                            <span style="--color:#2f3430"></span>
                            <span style="--color:#62675d"></span>
                            <span style="--color:#9a8c7d"></span>
                            <span style="--color:#d6d0c7"></span>
                        </div>
                    </article>
                </div>
            </section>

            <section class="section details reveal reveal-center">
                <h2>Детали</h2>
                <div class="details-text">
                    <p>
                        Уважаемые гости!<br>
                        Наше мероприятие рассчитано на взрослую публику. Поэтому просим вас оставить детей с вашими близкими!<br>
                        Благодарим за понимание.
                    </p>
                    <span class="details-divider"></span>
                    <p>
                        Мы искренне ценим ваше внимание и заботу!<br>
                        Если вы хотели дополнить свой подарок букетом цветов — мы будем признательны альтернативе в виде бутылочки вашего любимого вина или другого напитка.<br>
                        Цветы прекрасны, но, увы, не долговечны.
                    </p>
                </div>
            </section>

            <section class="section contacts reveal reveal-center">
                <h2>Контакты</h2>
                <p class="section-text">По всем вопросам о торжестве можете обращаться к нам:</p>
                <div class="contacts-list">
                    <div class="contacts-row">
                        <span>Невеста</span>
                        <a href="tel:<?= h($app['bride_phone_href']) ?>"><?= h($app['bride_phone']) ?></a>
                    </div>
                    <div class="contacts-row">
                        <span>Жених</span>
                        <a href="tel:<?= h($app['groom_phone_href']) ?>"><?= h($app['groom_phone']) ?></a>
                    </div>
                    <p class="contacts-note">или к ведущему</p>
                    <div class="contacts-row contacts-row--host">
                        <span><?= h($app['host_name']) ?></span>
                        <a href="tel:<?= h($app['host_phone_href']) ?>"><?= h($app['host_phone']) ?></a>
                    </div>
                </div>
            </section>

            <section class="section guest-form-section reveal reveal-center" id="guest-form-section">
                <h2>Анкета гостя</h2>
                <p class="section-text">Пожалуйста, подтвердите, сможете ли вы быть с нами в этот день.</p>
                <form class="guest-form" data-guest-form autocomplete="off">
                    <input type="hidden" name="csrf_token" value="<?= h($csrf) ?>">

                    <label class="line-field">
                        <span>Имя</span>
                        <input type="text" name="first_name" maxlength="80" required placeholder="Введите имя">
                    </label>

                    <label class="line-field">
                        <span>Фамилия</span>
                        <input type="text" name="last_name" maxlength="80" required placeholder="Введите фамилию">
                    </label>

                    <fieldset class="answer-fieldset">
                        <legend>Вы сможете прийти?</legend>
                        <label class="answer-option">
                            <input type="radio" name="attendance_status" value="yes" required>
                            <span>Да, приду</span>
                        </label>
                        <label class="answer-option">
                            <input type="radio" name="attendance_status" value="no" required>
                            <span>Нет, не смогу</span>
                        </label>
                    </fieldset>

                    <button class="button button--full" type="submit" data-submit-button>Отправить</button>
                    <p class="form-message" data-form-message role="status" aria-live="polite"></p>
                </form>
            </section>

            <section class="section gallery reveal reveal-center">
                <h2>До встречи на нашем празднике!</h2>
                <div class="photo-pair photo-pair--final">
                    <div class="photo-frame photo-pair__item photo-pair__item--left"><img src="assets/img/placeholders/gallery-1.svg" alt="Фото"></div>
                    <div class="photo-frame photo-pair__item photo-pair__item--right"><img src="assets/img/placeholders/gallery-2.svg" alt="Фото"></div>
                </div>
            </section>
        </main>

        <footer class="footer reveal reveal-center" data-wedding-date="<?= h($app['wedding_date']) ?>">
            <p class="footer-title">До свадьбы осталось...</p>
            <div class="timer" data-timer>
                <div><strong data-days>00</strong><span>дней</span></div>
                <div><strong data-hours>00</strong><span>часов</span></div>
                <div><strong data-minutes>00</strong><span>минут</span></div>
                <div><strong data-seconds>00</strong><span>секунд</span></div>
            </div>
        </footer>
    </div>

    <script src="assets/js/scroll-animations.js" defer></script>
    <script src="assets/js/music.js" defer></script>
    <script src="assets/js/timer.js" defer></script>
    <script src="assets/js/guest-form.js" defer></script>
    <script src="assets/js/app.js" defer></script>
</body>
</html>
